import pyodbc
import numpy as np
import matplotlib.pyplot as plt
import csv
import pandas as pd
import sqlalchemy

csv_path = "loadedmetrology.csv"
file = pd.read_csv(csv_path, delimiter=',')

file = file[file["Pass_Fail"] != r'\N']
file[file == r'\N'] = np.nan



columns = file.columns

querylines = "CREATE TABLE TROSA_101_LoadedMetrology("


for column in columns:

    column_sql = column.replace(" ", "_")
    column_sql = column_sql.replace("#", "_Number")
    column_sql = column_sql.replace("Index", "ind")

    file.rename(columns={column:column_sql},
                inplace=True)

    querylines = querylines+("%s float,"  %column_sql)



querylines = querylines + ("PRIMARY KEY (%s));" %columns[0])
# querylines = querylines[0:len(querylines)-2] + ");"



server = 'vl-mes-db01.velodyne.com'
database = 'labview'
username = 'VELODYNE\deng'
password = 'Danthemansand'
dsn = 'Velobase'
# cnxn = pyodbc.connect('SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
cnxn = pyodbc.connect( 'DSN='+dsn+';UID='+username+'PWD='+password )
# engine = sqlalchemy.create_engine("mssql+pyodbc://"+username+":"+password+"@"+dsn)
# # file.to_sql(name = "labview.dbo.TROSA_101_LoadedMetrology", con = engine, if_exists = 'append')
cursor = cnxn.cursor()
#
cursor.query()

# cols = '('
# rows = []
#
# for each in file.columns:
#
#     # rows = rows +"row["+each +'],'+'\n' +'\t'
#     cols = cols +"["+ each +'],' + '\n' + '\t'
#
# cols = cols[0:len(cols)-3]+')' +' values('+'?,'*(len(columns)-1)+'?)'
#
#
# full_query = cols
# full_query = full_query[0:len(full_query)-3] + ")"
#
# print("insert into labview.dbo.TROSA_101_LoadedMetrology("+full_query)
# cursor.executemany("insert into labview.dbo.TROSA_101_LoadedMetrology("+full_query)


# for index,row in file.iterrows():
#
#     print(row[Vendor])

    # cursor.execute(("insert into labview.dbo.TROSA_101_LoadedMetrology("+'\n' +'\t' +full_query))







#
# cursor.execute("INSERT INTO labview.dbo.TROSA_101_LoadedMetrology(")



# #cursor.execute("INSERT INTO labview.dbo.DELETE_THIS_TABLE(id, col1, col2, col3) VALUES (4, 5, 6, 7);")
# params = []
# for i in range(0,10):
#     point = (i,i-1,i+2,i**2)
#     params.append(point)
#
# print(params)
