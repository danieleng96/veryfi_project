import csv
from datetime import datetime

# make a text file called sns.txt
# copy paste all serial numbers from email (format A1234567) into sns.txt file.
# run this script, this will generate a query to input into MS SQL

now = datetime.now()
now = str(now)[:-3]
with open('sns.txt', newline='') as csvfile:
    lines = [line.rstrip() for line in csvfile]
    for each in lines:
        SN = each[0:4]+"-"+each[4::]
        # query = "UPDATE labview.dbo.SnStatus SET Status = \'FBN_FAI_Samples\' WHERE SerialNumber = \'"+SN+"\'"
        query = "INSERT INTO labview.dbo.SnStatus (SerialNumber, ProductName, Location, Status, TStamp) \n VALUES (\'{serial}\', \'TROSA_101\', \'WIP1\', \'Production\', \'{time}\')".format(serial = SN, time=now)
        print(query)
