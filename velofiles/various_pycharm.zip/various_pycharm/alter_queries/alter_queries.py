import csv
from datetime import datetime

# make 2 files called correct.txt with the new serialnumbers, and incorrect.txt for the incorrect SN's
# run this script, this will generate a query to input into MS SQL

all_tables = ['labview.dbo.TROSA_101_FinalTestingLD_FinalTestDazzle','labview.dbo.TROSA_101_FinalTestingLD_FinalTestDazzle_CH',
'labview.dbo.TROSA_101_FinalTestingLD_FinalTestLD','labview.dbo.TROSA_101_FinalTestingLD_FinalTestLD_CH'
,'labview.dbo.TROSA_101_InitialTestingAPD_ApdLifeTest'
,'labview.dbo.TROSA_101_InitialTestingAPD_ApdLifeTest_CH'
,'labview.dbo.TROSA_101_InitialTestingLD_AsicLpTest'
,'labview.dbo.TROSA_101_InitialTestingLD_AsicLpTest_CH'
,'labview.dbo.TROSA_101_InitialTestingLD_BootBiasCal'
,'labview.dbo.TROSA_101_InitialTestingLD_BootBiasCal_CH']
# now = datetime.now()
# now = str(now)[:-3]
with open('correct.txt', newline='') as correct:
    new_lines = [new.rstrip() for new in correct]
    with open('incorrect.txt', newline='') as incorrect:
        old_lines = [old.rstrip() for old in incorrect]
        for i,each in enumerate(new_lines):
            SN_new = each[0:4]+"-"+each[4::]
            SN_old = old_lines[i][0:4]+"-"+old_lines[i][4::]
            # print(SN_old)
            # print(SN_new)
            for table in all_tables:
                query = "UPDATE "+table+" SET SerialNumber = \'"+SN_new+"\' WHERE SerialNumber = \'"+SN_old+"\'"                # query = "INSERT INTO labview.dbo.SnStatus (SerialNumber, ProductName, Location, Status, TStamp) \n VALUES (\'" + SN + "\', \'TROSA_101\', \'WIP1\', \'NEW_LD_TEST\', \'" + now + "\')"
                print(query)
            status_query = "UPDATE labview.dbo.SnStatus SET Status = \'Previously " + SN_old + "\' Where SerialNumber = \'"+SN_old+"\'"
            sn_set = "UPDATE labview.dbo.SnStatus SET SerialNumber = \'" + SN_new + "\' WHERE SerialNumber = \'" + SN_old + "\'"
            print(status_query)
            print(sn_set)



# path = 'update_query.txt'
# text= open(path, 'r')
# text_string = str(text.read())
# #
# # table_name= "[TROSA_101_InitialTestingLD_BootBiasCal_CH]"
# # ind_range = 6677
# #
# # for line in changequeries:
# #     line = line.replace("TestIndex>7128", "TestIndex>"+"%d" % (ind_range))
# #     line = line.replace("[TROSA_101_InitialTestingAPD_ApdLifeTest_CH]",table_name)
#
# tables = ["TROSA_101_FinalTestingLD_FinalTestLD", "TROSA_101_FinalTestingLD_FinalTestLD_CH", "TROSA_101_InitialTestingAPD_ApdLifeTest", "TROSA_101_InitialTestingAPD_ApdLifeTest_CH", "TROSA_101_InitialTestingLD_AsicLpTest", "TROSA_101_InitialTestingLD_AsicLpTest_CH", "TROSA_101_InitialTestingLD_BootBiasCal", "TROSA_101_InitialTestingLD_BootBiasCal_CH", "SnStatus"]
# serial_dic_1_13_20 = {"wrong": ["B132-1630", "B102-1025", "B132-1624","B102-1199" ,"B132-1124"],
#             "correct": ["B130-1630", "B100-1025", "B130-1624", "B100-1199","B130-1124"]}
# # table = tables[len(tables)-1]
# class change_queries:
#
#     def __init__(self, tables_list, sn_dic):
#         self.tables_list = tables_list
#         self.sn_dic = sn_dic
#         self.wrong_sn = sn_dic["wrong"]
#         self.correct_sn = sn_dic["correct"]
#
#     def change_sn(self):
#         for table in self.tables_list:
#             for each in range(len(self.wrong_sn)):
#                 print(text_string %(table, self.correct_sn[each], self.wrong_sn[each]))
#
#     def show_former_sn(self):
#         str = "UPDATE [labview].[dbo].SnStatus \n SET Status='formerly_{}' \n WHERE SerialNumber='{}'\n"
#         for each in range(len(self.wrong_sn)):
#             print(str.format(self.wrong_sn[each], self.correct_sn[each]))
#
#
#
# edit_1_13_20 = change_queries(tables, serial_dic_1_13_20)
#
#
# # change_queries.change_sn(edit_1_13_20)
# change_queries.show_former_sn(edit_1_13_20)