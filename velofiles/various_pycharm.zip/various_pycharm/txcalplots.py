import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import csv
import os

full_df = {}
temps = []
ops = []
chs = []
files = os.listdir('results/results/')
# print(files)
# print(files)
for n, file in enumerate(files):
    if file.find('P5_T_') != -1:
        temps = []
        ops = []
        chs = []
        df = pd.read_csv("C:/Users/deng/Desktop/results/results/%s" % file)
        df = df.loc[:, 'Board':'Dazzle Rise Time']
        df = df.sort_values(['Board', 'TROSA', 'Channel', 'Power Level'])
        df = df[df["Power Level"] == 15]
        # df = df[df["Channel"] == 1]
        df_dict = {file: df}
        full_df.update({file: df})
        if df.size > 0:
            for i in df['Channel'].values:
                try:
                    temp = file[:-37][5::]
                    OP = df['Optical Power in mW'].values[i]
                    ch = df['Channel'].values[i]
                    ops.append(OP)
                    chs.append(ch)
                    temps.append(temp)
                    plt.scatter(temps, ops, marker='*',\
                                color=[(float(abs(int(ch))) * .1)** .01, (float(abs(int(ch))) * .1) ** .1,\
                                       float(abs(int(ch))) * .1], label=ch)
                except:
                    continue

plt.legend(loc = 'upper right')
ax = plt.axes()
ax.set(title ='Optical Power PL15', ylabel = 'OP mW', xlabel = 'Temp C')
plt.show()

        # print(full_df)
