import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
import matplotlib as mpl

# df75 = []
# df44 = []
full_df = {}

files = os.listdir('dazzle_data')
# print(files)

for file in files:
    if file.find('-85') != -1:
        df = pd.read_csv("file://localhost/Users/deng/Desktop/dazzle_data/%s" % file)
        df = df.loc[:, 'Board':'Pulse Amp(mV)']
        df = df.sort_values(['Board', 'TROSA', 'Channel', 'Power Level'])
        # df_all = df
        df = df[df["Power Level"] == 15]
        df_dict = {file: df}


        full_df.update({file: df})


    # all_df.update({file: df_all})






class comparisons:

        def __init__(self, A, B):
            self.A = A
            self.B = B

        # def regression(self, x, y, x0, m):
        # f = m*np.array(x)+x0


        def compare_files(self):


            if self.A and self.B in full_df:
                dat1 = full_df[self.A]
                dat2 = full_df[self.B]
                PL = dat1.loc[:,"Power Level"]

                daz1 = dat1.loc[:,"Dazzle Base Width":"Dazzle Sat Width"]
                daz2 = dat2.loc[:,"Dazzle Base Width":"Dazzle Sat Width"]

                ch = dat1.loc[:,"Channel"]
                ch = np.linspace(1,16,16)
                print(ch)
                comparison = daz1-daz2
                # comp_mean = comparison.mean(axis = 0)

                analytics = comparison.describe()
                print("{0} vs {1}".format(self.A, self.B))
                print(analytics.to_csv(index=False))
                # analytics[:2,"Dazzle Base Width"]
                # analytics_titles=analytics.insert(0,"{0} vs {1}".format(A, B),['count','mean','std','min','25%','50%','75%','max'],True)
                # print(type(analytics_titles))
                # analytics_titles = analytics_titles.to_csv(index=False)
                # average = analytics[1,"Dazzle Base Width"]

                line = np.arange(0, 100, 1)
                mpl.style.use('ggplot')
                graph1 = full_df[self.A]
                graph2 = full_df[self.B]
                PL = graph1.loc[:, 'Power Level']
                Base1 = graph1.loc[:, 'Dazzle Sat Width']
                Base2 = graph2.loc[:, 'Dazzle Sat Width']
                graph1['Board_abb'] = graph1.Board.str[:1]
                graph1['TROSA_abb'] = graph1.TROSA.str[:1]
                graph1['Label'] = graph1.Board_abb + graph1.TROSA_abb + graph1.Channel.astype('str')
                graph1['Label'] = graph1.Label.str[:-2]
                label = graph1.loc[:,'Label'].values.tolist()
                print(label)
                print(ch)


                # data = {'a': np.arange(50),
                #         'c': np.random.randint(0, 50, 50) * np.arange(50),
                #         'd': np.random.randn(50) * 10 / (np.arange(50) + 1)}
                # data['b'] = data['a'] + 10 * np.random.randn(50)
                # data['d'] = np.abs(data['d']) * 100

                plt.scatter(ch, Base1, c='y', marker='+', label=self.A)
                plt.scatter(ch, Base2, c='r', marker='*', label=self.B)
                plt.ylabel("Dazzle Sat Width (counts)")
                plt.xlabel("Channel")
                plt.title("Dazzle Sat Width vs Channel")
                for i, c in enumerate(ch):
                    plt.text(float(c) + 0.3, Base1.values.tolist()[i] + 0.3, label[i], c="olive", fontsize=8)




                plt.show()





# file1='P5_75_Aktar_0_191217131931.csv'
# file2='P5_75_Aktar_0_191217133349.csv'
# comp = comparisons(file1, file2)
# comp.compare_files()

class tup_comp:

    def __init__(self, *tup_files):
        self.tup_files = tup_files


    def graph_many(self):

        colorlist = ["#8080ff", "#ff4000", "y", "#0000b3" , "#00cccc", "#cc0000"]
        symbols = ["*", "+", "^", "x", "o", "."]

        for j,each in enumerate(self.tup_files):

             each_new = each[:-16]
             # each_new = each_new[16::]
             # each_new = each_new[::-1]
             print(each_new)

             if each in full_df:
                 dat = full_df[each]
                 daz = dat.loc[:, "Dazzle Base Width":"Dazzle Sat Width"]

                 ch = np.linspace(1, 16, 16)
                 dat['Board_abb'] = dat.Board.str[:1]
                 dat['TROSA_abb'] = dat.TROSA.str[:1]
                 label = dat.Board_abb+dat.TROSA_abb+dat.Channel.astype('str')
                 label = label.values.tolist()

                 sat_wid = dat.loc[:, "Dazzle Sat Width"].values.tolist()

                 mpl.style.use('dark_background')

                 plt.scatter(ch, sat_wid, c=colorlist[j], marker=symbols[j], label=each)
                 plt.ylabel("Dazzle Sat Width (counts)")
                 plt.xlabel("Channel")
                 plt.title("Dazzle Sat Width vs Channel")

                 if j == 1:
                    for i, c in enumerate(ch):
                        plt.text(c + 0.1, sat_wid[i] + 0.1, label[i], c="olive", size=8)
                 # colorbase = + 200



        plt.show()



three = tup_comp("P5_44_Aktar_2cm_7_191218153216.csv","P5_44_cardboard_7_191218164226.csv","P5_44_Aktar_0_191217103909.csv","P5_75_Aktar_0_191218114550.csv","P5_75_Aktar_0_191218113053.csv")
three.graph_many()
