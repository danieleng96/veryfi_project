# path = 'sn121619.txt'
# text = open(path, 'r')
# text_str = text.read()
# i = 0
# SN_list = []
#
#
# print(text_str)
# for line in text_str:
#     print(line)
