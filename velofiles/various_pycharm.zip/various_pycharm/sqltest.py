import pyodbc
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# server = 'vl-mes-db01.velodyne.com'
# database = 'labview'
# username = 'VELODYNE\deng'
# password = 'Danthemansand'
# # cnxn = pyodbc.connect('ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
# cnxn = pyodbc.connect( 'DSN=Velobase;UID='+username+'PWD='+password )
# cursor = cnxn.cursor()
#
# #cursor.execute("INSERT INTO labview.dbo.DELETE_THIS_TABLE(id, col1, col2, col3) VALUES (4, 5, 6, 7);")
# params = []
# for i in range(0,10):
#     point = (i,i-1,i+2,i**2)
#     params.append(point)
#
# print(params)

class case:
    def __init__(self, nom, vowel_thickness, acc_vowels, cons):
        self.nom = nom
        self.thickness = vowel_thickness
        self.acc_vowels = acc_vowels
        self.cons = cons


    def accusative(self):
        rev = self.nom[::-1]
        ind = -1
        for letter in rev:
            print(letter)
            ind =+ 1
            ending = ""
            # if ind == 0 and letter in self.acc_vowels.keys():
            #     ending = "y" + self.acc_vowels[letter]
            #     break
            if ind == 0 and letter in self.cons.keys():
                self.nom = self.nom[0:len(self.nom) - 2] + self.cons[letter]
                print(self.nom)
                ending = self.cons[letter]
            elif letter in self.acc_vowels.keys():
                ending = ending + self.acc_vowels[letter]
                break


        accusative = self.nom + ending

        return(self.nom, accusative)




thickness = {"a": "a", "ı": "a", "o": "a", "u": "a", "e": "e", "i": "e", "ö": "e", "ü": "e"}
acc_pres = {"a": "ı", "ı": "ı", "o": "u", "u": "u", "e": "i", "i": "i", "ö": "ü", "ü": "ü"}
nom = "köpek"
con_change = {"ç":"c", "k":"ğ", "t":"d", "p":"b"}

c = case(nom, thickness, acc_pres, con_change)
acc = c.accusative()
print(acc)




#     def noun_cases(nom, subject):
#
#
#
#         rev = nom[::-1]
#
#
#
#
#
#
#
#     string = "koruşmek"
#     def present(string):
#         root = string[0:len(string)-3]
#         rev = root[::-1]
#         vowels = [["a","ı"],["o","u"],["ö","ü"],["e","i"]]
#
#         con_change = {"ç":"c", "k":"g", "t":"d"}
#         allvowels = [vowel for grouping in vowels for vowel in grouping]
#
#         ind = -1
#         for letter in rev:
#             ind = ind+1
#
#             if ind == 0 and letter in allvowels:
#                 root = root[0:len(root)-1]
#                 order = allvowels.index(letter)
#                 if order % 2 == 0:
#                     letter = allvowels[order + 1]
#                 break
#             elif ind != 0 and letter in allvowels:
#                 order = allvowels.index(letter)
#                 if order % 2 == 0:
#                     letter = allvowels[order + 1]
#                 break
#             elif ind == 0 and letter in con_change.keys():
#                 root = root[0:len(root)-1] + con_change[letter]
#
#
#
#
#
#         return(root + letter +"yor")
#
#
#
#
#
# print(present(string))

#     for letter in rev:
#         if letter in
#
#
#
#
# def insertsql(data):
#     try:
#         cnxn.autocommit = False
#         cursor.executemany("INSERT INTO labview.dbo.DELETE_THIS_TABLE(id, col1, col2, col3) VALUES (?, ?, ?, ?);", data)
#     except pyodbc.DatabaseError as err:
#         cnxn.rollback()
#     else:
#         cnxn.commit()
#     finally:
#         cnxn.autocommit = True
#
#
#
# insertsql(params)
#
