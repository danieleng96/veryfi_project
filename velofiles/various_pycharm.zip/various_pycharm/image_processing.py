from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from PIL import ImageFilter
import cv2
import pandas as pd
from matplotlib.widgets import Slider, Button

a = np.zeros((700,700))
a.reshape((700,700))
for i in range(70):
    a[::i*3+1] = 255

thresh = 130

im = Image.open('pseudolaser.jpg').convert('L')
sin_np = Image.open('sinish.jpg').convert('L')

sinish_c = cv2.imread('sinish.jpg', cv2.IMREAD_COLOR)
sinish = cv2.imread('sinish.jpg', cv2.IMREAD_GRAYSCALE)
sinish_bin = cv2.threshold(sinish, thresh, 255, cv2.THRESH_BINARY)[1]

array = np.array(im)

maxes = np.argmax(sinish_bin, axis=0)
indices = []
max = []

for i, each in enumerate(maxes):
    if i > 0:
        if each != 0 and each+maxes[i-1]+maxes[i+1] != each and np.abs(each - maxes[i-1]) <= 40:
            cv2.drawMarker(sinish_c, (i, each), color=(500-i,i,2*i))
            max.append(each)
            indices.append(i)

        else:
            continue
# fourier = np.fft.fft(maxes[44:389])
# avg = np.average(fourier)
# print(avg)
# fig, ax = plt.subplots()
# ax.plot(fourier,'x', linewidth = 3, color='navy')
# ax.set(ylim=[-2, 2])
# plt.show()
# plt.plot(maxes[44:389], 'x', linewidth = 5, color = 'firebrick')
imag = plt.imread("sinish.jpg")
fig, ax = plt.subplots()
ax.imshow(imag)
ax.plot(indices, max, '*', linewidth=5, color='firebrick')
plt.show()

cv2.imshow('sine',sinish_c)
cv2.waitKey(10000)

img = cv2.imread('pseudolaser.jpg', cv2.IMREAD_COLOR)
img_grey = cv2.imread('pseudolaser.jpg', cv2.IMREAD_GRAYSCALE)
img_binary = cv2.threshold(img_grey, thresh, 255, cv2.THRESH_BINARY)[1]
edges = cv2.Canny(img_binary, 50, 150, apertureSize = 3)

lines = cv2.HoughLinesP(edges, 1, np.pi/180, 20, minLineLength = 300, maxLineGap=35)
ft = np.fft.fft2(im, axes=(1,1))

# for rho,theta in lines[0]:
#     print(rho)
#     print(theta)
#     a = np.cos(theta)
#     b = np.sin(theta)
#     x0 = a * rho
#     y0 = b * rho
#     x1 = int(x0 + 1000 * (-b))
#     y1 = int(y0 + 1000 * (a))
#     x2 = int(x0 - 1000 * (-b))
#     y2 = int(y0 - 1000 * (a))

def sorting_list(line_array):
    a = np.squeeze(line_array, axis = 1)
    df = pd.DataFrame({'x1':a[:,0], 'y1':a[:,1], 'x2':a[:,2], 'y2':a[:,3]})

    df = df.sort_values(by=['y1', 'y2'])
    line = df.to_numpy()
    line = np.expand_dims(line, axis = 1)
    return line

a = sorting_list(lines)
print(a)

for i, each in enumerate(a):
    for x1, y1, x2, y2 in a[i]:
        if np.abs(y1-y2) < 30:
            cv2.line(img,(x1,y1), (x2,y2), (0,255,255),2)
            cv2.drawMarker(img,(int((x2-x1)*0.5), y1), color=(200,50*i,30*i))
            if i > 0:
                y1_1_av = abs(int((a[i-1][0,1]+a[i-1][0,3])*0.5))
                cv2.line(img,(int((x2-x1)*0.5), int((y2+y1)*0.5)), (int((x2-x1)*0.5),y1_1_av), color = (153, 214, 255))
                dy = int((y2 + y1) * 0.5)-y1_1_av
                cv2.line(img, (0, int((y2 + y1) * 0.5)+dy*i), (400, int((y2 + y1) * 0.5)+dy*i), color = (0, 204, 51))
                print(dy)
        else:
            # cv2.line(img,(x1,y1),(x2,y2),(100,180,40),2)
            continue
cv2.imshow('lines', img)
cv2.waitKey(1500)

# image = Image.fromarray(ft,'L')
# image.show()
# for i in range(320):
#     array[i*2,200:640] = 0
#     array[200:640,i*2] = 255
# img = img.filter(ImageFilter.BLUR)
# img = img.filter(ImageFilter.BoxBlur)
# img = img.filter(ImageFilter.GaussianBlur)
# imagewithedges = img.filter(ImageFilter.FIND_EDGES)
# array_edges = np.array(imagewithedges)
# for i in range(array.shape[0]):
#     for j in range(array.shape[1]):
#         if array_edges[i,j] == 0:
#             array[i,j] = array_edges[i,j]
#         # elif array_edges[i,j] == 255:
#         #     array[i,j] = array_edges[i,j]
# img = Image.fromarray(array, 'L')
# imagewithedges.show()