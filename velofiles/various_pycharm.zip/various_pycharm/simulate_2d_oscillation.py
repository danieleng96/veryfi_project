from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from PIL import ImageFilter
import cv2
import pandas as pd
from matplotlib.widgets import Slider, Button

def signal(amp, freq, phi, offset):
    return offset + amp * np.sin(2*np.pi*freq*t + phi)

axis_color = 'lightgoldenrodyellow'

fig = plt.figure()
imag = plt.imread("sinish.jpg")
ax = fig.add_subplot(111)



fig.subplots_adjust(left = 0.25, bottom = 0.35)

ax.imshow(imag, extent=[-10, 10, -10, 10])
t = np.arange(0, 3.2, 0.001)
x_0= 0
y_0 = 0
x_amp = 10
y_amp = 1
x_freq = 1
y_freq = 2
x_phi = 0
y_phi = 0
wobble_freq = .75


X = signal(x_amp, x_freq, x_phi, x_0)
Y = signal(y_amp, y_freq, y_phi, y_0)

[line] = ax.plot(X, Y, linewidth = 2, color='firebrick')
ax.set_xlim([-10,10])
ax.set_ylim([-10,10])

amp_slider_ax = fig.add_axes([0.25, 0.2, 0.65, 0.03])
amp_slider = Slider(amp_slider_ax, 'Y Amp', 0.1, 10, valinit = y_amp)

freq_slider_ax = fig.add_axes([0.25, 0.15, 0.65, 0.03])
freq_slider = Slider(freq_slider_ax, 'Y Frequency', 0.1, 20, valinit = y_freq)

phi_slider_ax = fig.add_axes([0.25, 0.1, 0.65, 0.03])
phi_slider = Slider(phi_slider_ax, 'Y Phase (radians)', np.pi/64, 2*np.pi, valinit = y_phi)

offset_slider_ax = fig.add_axes([0.25, 0.05, 0.65, 0.03])
offset_slider = Slider(offset_slider_ax, 'Y offset', 0.1, 10, valinit = y_0)

def sliders_on_changed(val):
    line.set_ydata(signal(amp_slider.val, freq_slider.val, phi_slider.val, offset_slider.val))
    fig.canvas.draw_idle()

amp_slider.on_changed(sliders_on_changed)
freq_slider.on_changed(sliders_on_changed)
phi_slider.on_changed(sliders_on_changed)
offset_slider.on_changed(sliders_on_changed)

reset_button_ax = fig.add_axes([0.8, 0.025, 0.1, 0.04])
reset_button = Button(reset_button_ax, 'Default', color=axis_color, hovercolor = '0.975')
def reset_button_on_clicked(mouse_event):
    freq_slider.reset()
    amp_slider.reset()
    phi_slider.reset()
    offset_slider.reset()
reset_button.on_clicked(reset_button_on_clicked)

plt.show()




# print(X)
#
# fig, ax = plt.subplots()
# ax.plot(X, Y , '*', linewidth=5, color='firebrick')
# ax.set(ylim = [-10,10], xlim=[-10, 10])
# plt.show()