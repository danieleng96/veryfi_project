from pylablib.aux_libs.devices import Thorlabs

serial_y='27255818'
serial_x='27255783'

# print(lab.pm.Meas_Pow())
#steps per degree
pos_conv = 136533

conn1 = Thorlabs.KDC101(serial_y)
conn2 = Thorlabs.KDC101(serial_x)




starting_step = 10000

def cycle(connection):
    connection.move_to(0)
    connection.wait_for_stop()
    while connection.get_position()/pos_conv < 1.4:
        print(connection.get_position())
        connection.move(0.25*pos_conv)
        connection.wait_for_stop()
        print(connection.get_position()/pos_conv)
    connection.move_to()
    connection.wait_for_stop()

def move_to_zero(connection):
    connection.move_to(0)
    connection.wait_for_stop()
    connection.get_position()
    connection.move(4000)
conn2.move_to(253489)
conn2.wait_for_stop()
conn1.move_to(229415)
conn1.wait_for_stop()
print('X: SN {0}, position {1}'.format(serial_x, str(conn1.get_position())))
print('Y: SN {0}, position {1}'.format(serial_y, str(conn2.get_position())))

