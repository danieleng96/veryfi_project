import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib as mpl

# data = {'a': np.arange(50),
#         'c': np.random.randint(0, 50, 50) * np.arange(50),
#         'd': np.random.randn(50)*10 / (np.arange(50)+1)}
# data['b'] = data['a'] + 10 * np.random.randn(50)
# data['d'] = np.abs(data['d']) * 100
#
# ch = np.arange(0,50)
# y = np.random.randint(0, 50, 50)
# d = np.random.randint(0,50, 1)
#
# plt.plot(ch, y, c='r', marker='*', markersize = d)
# plt.scatter('a', 'b', c='c', s='d', data=data)
# plt.xlabel('entry a')
# plt.ylabel('entry b')
# plt.show()

# v = ['a','e','i','o','u','ü','ö','ı']
# phr = [x+'ç' for x in v]
# print(phr)

# df = pd.read_csv('turkish.txt', sep='\t')
# words = df.loc[:,'turkish':'english']
#
# words['lower_turkish'] = filter(lambda x: x.lower(), words['turkish'])
#
# specific_word = ['bunu']
# word_search = df.loc[df['turkish'].isin(specific_word)]
# print(words.loc[0:50,'turkish':'english'])


# first = lower['turkish'].str[:1]
#
# print(first.value_counts())

r = 5
d = np.linspace(0,100)
blank = np.zeros(d.shape[0])
one = np.ones(d.shape[0])

theta = np.arctan2(d,r)
print(theta)


ind = 20
der = []
for i in range(d.shape[0]):
        if i != 0:
                deriv = (theta[i-1]-theta[i])/(d[i-1]-d[i])
        else:
                deriv = 0
        der.append(deriv)

print(der)
# fig = plt.scatter(theta, blank, c="olive", marker = "*")
# fig.axes.get_yaxis().set_visible(False)
# plt.scatter(der, one, c="teal")
#
# plt.plot([theta[3],theta[5]],[theta[30],0])
left = -2
right = 2
rad = 1

r = np.arange(0, 2, 0.01)
theta = 2 * np.pi * r**2

x= np.sqrt(2)
R=x**2
ax = plt.subplot(111, projection='polar')



number_points = 50
thetas = np.linspace(0, np.pi, number_points)
dt= thetas[1]-thetas[0]

x= np.sqrt(2)
rad = x
rady = R
coords_x = []
coords_y = []

for i, each in enumerate(thetas):
        if each >= 0 and each < np.pi/4:
            rad = rad + dt*x*(np.sin(each)/((np.cos(each))**2))
            ax.plot((each, each), (0, rad), c="r", zorder = 3)
            ax.plot((np.pi-each,np.pi-each), (0, rad), c="r", zorder=3)
            coords_x.append(x)
            coords_x.append(-x)
            coords_y.append(rad*np.sin(each))
            coords_y.append(rad*np.sin(each))
        elif each >= np.pi/4 and each < 3*np.pi/4:
            rady = rady - dt*x*(np.cos(each)/((np.sin(each))**2))
            ax.plot((each, each), (0, rady), c="b", zorder=3)
            coords_x.append(rady*np.cos(each))
            coords_y.append(x)





ax.plot((3*np.pi/4, np.pi/4), ( R, R), c = "b", zorder = 3)
ax.plot((3*np.pi/4, np.pi), (R,x), c="b", zorder = 3)
ax.plot((np.pi/4, 0), (R,x), c="b", zorder = 3)
# plt.plot([left,right],[rad,rad], c="r")
# plt.plot([left,left],[rad,0], c="r")
# plt.plot([right,right],[rad,0], c="r")
fig, ax = plt.subplots(nrows=1, ncols=1)

plt.plot((-x,x), (x,x), c="y")
plt.plot((-x,-x), (x,0), c="y")
plt.plot((x,x), (0,x), c="y")
plt.scatter(coords_x, coords_y, marker="o")



# x = np.arange(0, 1000)
# f = np.arange(0, 1000)
# g = np.sin(np.arange(0, 10, 0.01) * 2) * 1000
#
# plt.plot(x, f, '-')
# plt.plot(x, g, '-')
#
# idx = np.argwhere(np.diff(np.sign(f - g))).flatten()
# plt.plot(x[idx], f[idx], 'ro')
plt.show()





